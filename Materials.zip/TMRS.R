# PAPER CODE – TMRS / Two Mode Relational Simmilarity
# Estimation followed the procedures described and presented by 
# Lizardo, O. (2024). Two-mode relational similarities. Social Networks, 76, 34–41. https://doi.org/10.1016/j.socnet.2023.06.002

# Data Availability:
# The following code reproduces the TMRS (Two-Mode Relational Similarity) results.
# The dataset is publicly available on the GitHub repository of the paper and 
# consists of four edgelists, each representing the corpus for a specific period.


# Note: The data has been edited to ensure anonymity
# and to comply with the data use requirements of data providers (SciSciNet and OpenAlex).

#Libraries

library(dplyr)
library(furrr)
library(purrr)
library(igraph)
library(network)
library(sna)
library(tidygraph)
library(tidyverse)
library(stringr)
library(cluster)
library(ggdendro)

# 1.- Data 

#First 2 Quinquenials 

M1 <- read_csv("~/yourlocation/edge_tmrs_d1.csv")

M1_2000_2005 <- M1 %>% filter(Year >= 2000 & Year <= 2005)

# Filter M1 for the year range 2006 to 2010
M1_2006_2010 <- M1 %>% filter(Year >= 2006 & Year <= 2010)

# Direct matrix version (lighter in size)
affiliation_matrix1 <- as.matrix(table(M1_2000_2005$PaperID, M1_2000_2005$Field))
affiliation_matrix2 <- as.matrix(table(M1_2006_2010$PaperID, M1_2006_2010$Field))




#Last 2 Quinquenials 

M2 <- read_csv("~/yourlocation/edge_tmrs_d2.csv")

M2_2011_2015 <- M2 %>% filter(Year >= 2011 & Year <= 2015)

# Filter M1 for the year range 2006 to 2010
M2_2016_2021 <- M2 %>% filter(Year >= 2016 & Year <= 2021)

# Direct matrix version (lighter in size)
affiliation_matrix3 <- as.matrix(table(M2_2011_2015$PaperID, M2_2011_2015$Field))
affiliation_matrix4 <- as.matrix(table(M2_2016_2021$PaperID, M2_2016_2021$Field))




# 2.- Setting Functions

#Distance Matrix
get.dist <- function(x) {
  distance_matrix <- 1 - x 
  
  if(any(is.na(distance_matrix))) {
    distance_matrix <- na.omit(distance_matrix)
  }
  return(as.matrix(distance_matrix))
}

#Multidimensional Scaling
get.mds <- function(x) {
  
  if(any(is.na(x))) {
    warning("Input matrix contains NA values. Attempting to remove rows with NA.")
    
    x <- na.omit(x)
    
    if (nrow(x) < 2) {
      stop("Not enough data remaining after removing NA values for MDS.")
    }
  }
  
  distance_matrix <- get.dist(x)
  if (nrow(distance_matrix) < 2) {
    stop("Distance matrix does not have enough dimensions for MDS.")
  }
  x_mds <- cmdscale(distance_matrix)
  colnames(x_mds) <- c("Dim.1", "Dim.2")
  
  return(x_mds)
}

#Clusttering

get.clus <- function(x, k = 3) {
  hclus.cent <- tibble(cluster = eclust(x, "hclust", method = "ward.D2",
                                        k = k, graph = FALSE)$cluster) %>% 
    cbind(x)  %>% 
    group_by(cluster) %>% 
    summarize(across(starts_with("Dim"), mean)) %>% 
    dplyr::select(-1)
  km.clust <- eclust(x, "kmeans", 
                     k = hclus.cent, graph = FALSE)$cluster 
  n <- rownames(x)
  # K-Means Clustering
  x <- as_tibble(cbind(x, cluster = km.clust)) %>% 
    mutate(cluster = factor(cluster)) %>% 
    mutate(names = n)
  return(x)    
}


# 3.- Estimations

#A1 Generalized Simmilarity Correlation

gen.sim.corr.abs <- function(x, sigma = 0.01) {
  library(expm) 
  r <- nrow(x) 
  c <- ncol(x)
  r.c <- diag(r) 
  c.c <- diag(c) 
  r.m <- rowMeans(x, na.rm = TRUE) 
  c.m <- colMeans(x, na.rm = TRUE) 
  d.r.c <- Inf 
  d.c.c <- Inf
  k <- 1 
  
  while (d.r.c > sigma | d.c.c > sigma) {
    
    p.r.c <- r.c 
    p.c.c <- c.c 
    
    for (i in 1:r) {
      for (j in 1:r) {
        if (i != j) {
          r.x <- x[i, ] - r.m[i]
          r.y <- x[j, ] - r.m[j]
          
          r.xy <- sum(r.x * r.y) 
          r.xx <- sum(r.x^2) 
          r.yy <- sum(r.y^2) 
          
          if (r.xx != 0 && r.yy != 0) {
            r.c[i, j] <- r.xy / sqrt(r.xx * r.yy) 
          } else {
            r.c[i, j] <- 0 
          }
        }
      }
    }
    
    for (i in 1:c) {
      for (j in 1:c) {
        if (i != j) {
          c.x <- x[, i] - c.m[i]
          c.y <- x[, j] - c.m[j]
          
          c.xy <- sum(c.x * c.y) 
          c.xx <- sum(c.x^2) 
          c.yy <- sum(c.y^2) 
          
          if (c.xx != 0 && c.yy != 0) {
            c.c[i, j] <- c.xy / sqrt(c.xx * c.yy) 
          } else {
            c.c[i, j] <- 0 
          }
        }
      }
    }
    
    d.r.c <- sum(abs(p.r.c - r.c))
    d.c.c <- sum(abs(p.c.c - c.c))
    k <- k + 1
    
    if (k > 1000) {
      warning("Maximum iterations reached")
      break
    }
  }
  
  rownames(r.c) <- rownames(x)
  colnames(r.c) <- rownames(x)
  rownames(c.c) <- colnames(x)
  colnames(c.c) <- colnames(x)
  
  return(list(row.sims = r.c, col.sims = c.c, n.iter = k)) # Return rowwise and columnwise generalized similarities
}


#A2 Correlation Distance

corr.dist <- function(x) {
  r <- nrow(x)
  c <- ncol(x)
  r.c <- matrix(0, r, r)
  c.c <- matrix(0, c, c)
  r.m <- rowMeans(x)
  c.m <- colMeans(x)
  
  for (i in 1: r) {
    for (j in 1:r) {
      r.x <- x[i, ] - r.m[i]
      r.y <- x[j, ] - r.m[j]
      r.xy <- r.x * t(r.y)
      r.xx <- r.x * t(r.x)
      r.yy <- r.y * t(r.y)
      r.num <- sum(r.xy)
      r.den <- sqrt(sum(r.xx)) * sqrt(sum(r.yy))
      r.c[i, j] <- round(r.num / r.den, 2)
    }
  }
  for (i in 1: c) {
    for (j in 1:c) {
      c.x <- x[, i] - c.m[i]
      c.y <- x[, j] - c.m[j]
      c.xy <- c.x * t(c.y)
      c.xx <- c.x * t(c.x)
      c.yy <- c.y * t(c.y)
      c.num <- sum(c.xy)
      c.den <- sqrt(sum(c.xx)) * sqrt(sum(c.yy))
      c.c[i, j] <- round(c.num / c.den, 2)
    }
  }
  
  rownames(r.c) <- rownames(x)
  colnames(r.c) <- rownames(x)
  rownames(c.c) <- colnames(x)
  colnames(c.c) <- colnames(x)
  return(list(row.corrs = r.c, col.corrs = c.c))
}


#A3 Two-Mode Correlation Distance

tm.corr.dist <- function(x) {
  library(expm)
  r <- nrow(x)
  c <- ncol(x)
  r.c <- diag(r) 
  c.c <- diag(c)
  r.m <- rowMeans(x, na.rm = TRUE) 
  c.m <- colMeans(x, na.rm = TRUE) 
  
  tm.sim <- function(x) {
    r <- nrow(x)
    c <- ncol(x)
    r.r <- x %*% t(x) 
    c.c <- t(x) %*% x 
    r.s <- diag(r) 
    c.s <- diag(c) 
    
    sim <- function(a, b, c) {
      if (b == 0 || c == 0) {
        return(0) 
      } else {
        return(a / sqrt(b * c))  
      }
    }
    
    for (i in 1:r) {
      for (j in 1:r) {
        if (i != j) {
          r.s[i, j] <- sim(r.r[i, j], r.r[i, i], r.r[j, j])
        }
      }
    }
    
    for (i in 1:c) {
      for (j in 1:c) {
        if (i != j) {
          c.s[i, j] <- sim(c.c[i, j], c.c[i, i], c.c[j, j])
        }
      }
    }
    
    rownames(r.s) <- rownames(x)
    colnames(r.s) <- rownames(x)
    rownames(c.s) <- colnames(x)
    colnames(c.s) <- colnames(x)
    return(list(row.sims = r.s, col.sims = c.s))
  }
  
  sim.res <- tm.sim(x)
  r.s <- sim.res[[1]]
  c.s <- sim.res[[2]]
  
  for (i in 1:r) {
    for (j in 1:r) {
      if (i != j) {
        r.x <- x[i, ] - r.m[i]
        r.y <- x[j, ] - r.m[j]
        r.xy <- r.x %*% c.s * t(r.y)
        r.xx <- r.x %*% c.s * t(r.x)
        r.yy <- r.y %*% c.s * t(r.y)
        r.num <- sum(r.xy)
        r.den <- sqrt(sum(r.xx)) * sqrt(sum(r.yy))
        if (r.den != 0) {
          r.c[i, j] <- round(r.num / r.den, 2)
        } else {
          r.c[i, j] <- 0 
        }
      }
    }
  }
  
  for (i in 1:c) {
    for (j in 1:c) {
      if (i != j) {
        c.x <- x[, i] - c.m[i]
        c.y <- x[, j] - c.m[j]
        c.xy <- c.x %*% r.s * t(c.y)
        c.xx <- c.x %*% r.s * t(c.x)
        c.yy <- c.y %*% r.s * t(c.y)
        c.num <- sum(c.xy)
        c.den <- sqrt(sum(c.xx)) * sqrt(sum(c.yy))
        if (c.den != 0) {
          c.c[i, j] <- round(c.num / c.den, 2)
        } else {
          c.c[i, j] <- 0 
        }
      }
    }
  }
  
  rownames(r.c) <- rownames(x)
  colnames(r.c) <- rownames(x)
  rownames(c.c) <- colnames(x)
  colnames(c.c) <- colnames(x)
  
  return(list(row.sims = r.c, col.sims = c.c))
}


# 4.- Implementation

#Quinquenial 1 
tm1 <- tm.corr.dist(affiliation_matrix1)


#Performing MDS 
mds.tm.a1 <- get.mds(tm1$row.sims)
mds.tm.e1 <- get.mds(tm1$col.sims)

# Performing Clustering
clus.tm.a1 <- get.clus(mds.tm.a1)
clus.tm.e1 <- get.clus(mds.tm.e1)


#Quinquenial 2 
tm2 <- tm.corr.dist(affiliation_matrix2)

#Performing MDS 
mds.tm.a2 <- get.mds(tm2$row.sims)
mds.tm.e2 <- get.mds(tm2$col.sims)

# Performing Clustering}
clus.tm.a2 <- get.clus(mds.tm.a2)
clus.tm.e2 <- get.clus(mds.tm.e2)



#Quinquenial 3 
tm3 <- tm.corr.dist(affiliation_matrix3)

#Performing MDS 
mds.tm.a2 <- get.mds(tm2$row.sims)
mds.tm.e2 <- get.mds(tm2$col.sims)

# Performing Clustering}
clus.tm.a3 <- get.clus(mds.tm.a3)
clus.tm.e3 <- get.clus(mds.tm.e3)


#Quinquenial 4 
tm4 <- tm.corr.dist(affiliation_matrix4)

#Performing MDS 
mds.tm.a4 <- get.mds(tm4$row.sims)
mds.tm.e4 <- get.mds(tm4$col.sims)

# Performing Clustering
clus.tm.a4 <- get.clus(mds.tm.a4)
clus.tm.e4 <- get.clus(mds.tm.e4)



#5.- Plot function

custom_palette <- c(
  "cornflowerblue", 
  "mediumseagreen",  
  "darkgoldenrod1")


get.plot <- function(x, t = "", fsize = 3, pal = custom_palette) {
  sampled_labels <- x %>%
    group_by(cluster) %>%
    sample_n(1)  
  
  p <- ggscatter(x, x = "Dim.1", y = "Dim.2", 
                 color = "cluster",
                 palette = pal,
                 size = 1.5,
                 ellipse.type = "convex",
                 ellipse = TRUE,
                 ellipse.alpha = 0.25,
                 ellipse.border.remove = TRUE,
                 repel = TRUE)
  
  p <- p + geom_label(data = sampled_labels, aes(label = names), 
                      size = fsize, color = "#656565", fill = NA, label.size = 0, 
                      show.legend = FALSE, fontface = "bold")
  
  p <- p + theme_minimal()
  p <- p + theme(legend.position = "bottom", 
                 axis.text = element_text(size = 16),
                 axis.title = element_text(size = 20),
                 title = element_text(size = 17))
  p <- p + scale_y_continuous(limits = c(-0.4, 0.4))
  p <- p + scale_x_continuous(limits = c(-0.6, 0.6))
  p <- p + ggtitle(t)
  return(p)
}

#Plots

#Quinquenial 1

plot_tmrs1a <- get.plot(clus.tm.a1, t = "TMRS for SciSciNET Papers (2000-2005)")
plot_tmrs1b <- get.plot(clus.tm.e1, t = "TMRS for SciSciNET Fields (2000-2005)")

#Quinquenial 2

plot_tmrs2a <- get.plot(clus.tm.a2, t = "TMRS for SciSciNET Papers (2006-2010)")
plot_tmrs2b <- get.plot(clus.tm.e2, t = "TMRS for SciSciNET Fields (2006-2010)")

#Quinquenial 3

plot_tmrs3a <- get.plot(clus.tm.a3, t = "TMRS for SciSciNET Papers (2010-2015)")
plot_tmrs3b <- get.plot(clus.tm.e3, t = "TMRS for SciSciNET Fields (2010-2015)")

#Quinquenial 4

plot_tmrs4a <-get.plot(clus.tm.a4, t = "TMRS for SciSciNET Papers (2016-2021)")
plot_tmrs4b <-get.plot(clus.tm.e4, t = "TMRS for SciSciNET Fields (2016-2021)")


###  Robustness for TMRS number K

#1.- Dendogram for Fields 

# Quinquenial 1

# Extract TMRS matrices
for (i in seq_along(tm1)) {
  assign(paste0("A_element_", i), tm1[[i]])
}

# Perform hierarchical clustering 
hc1 <- hclust(as.dist(A_element_1), method = "median")

# Plot

hc_data1 <- ggdendro::dendro_data(hc1)

set.seed(123) 
sampled_labels <- hc_data1$labels[sample(nrow(hc_data1$labels), 50), ]

plotden1 <- ggplot() +
  geom_segment(data = hc_data1$segments, aes(x = x, y = y, xend = xend, yend = yend)) +
  geom_label(data = sampled_labels, aes(x = x, y = y, label = label), 
             hjust = 1, vjust = 1, angle = 90, size = 3, fill = "cornflowerblue", label.size = 0) +
  # Add a dashed horizontal line for cluster 3
  geom_hline(yintercept = 0.097, linetype = "dashed", color = "coral", size = 1) +
  labs(title = "TMRS Field Dendrogram (2000-2005)", 
       x = "", y = "Cos. Similarity Distance", caption = "Total 1.801 Abstracts") +
  theme_minimal() +
  theme(axis.text.x = element_blank(),
        axis.ticks.x = element_blank(),
        panel.grid.major = element_blank(),
        panel.grid.minor = element_blank())

plotden1 <- ggplot() +
  geom_segment(data = hc_data1$segments, 
               aes(x = x, y = pmax(y, 0), xend = xend, yend = pmax(yend, 0))) + 
  labs(title = "TMRS Field Dendrogram (2000-2005)", 
       x = "", y = "Cos. Similarity Distance", caption = "Total 1.801 Abstracts") +
  theme_minimal() +
  theme(axis.text.x = element_blank(),
        axis.ticks.x = element_blank(),
        panel.grid.major = element_blank(),
        panel.grid.minor = element_blank())


# Quinquenial 2

# Extract TMRS matrices
for (i in seq_along(tm2)) {
  assign(paste0("A_element_", i), tm2[[i]])
}

# Perform hierarchical clustering 
hc2 <- hclust(as.dist(A_element_2), method = "median")

# Plot

hc_data2 <- ggdendro::dendro_data(hc2)


plotden2 <- ggplot() +
  geom_segment(data = hc_data2$segments, aes(x = x, y = y, xend = xend, yend = yend))  +
  # Add a dashed horizontal line for cluster 3
  geom_hline(yintercept = 0.09, linetype = "dashed", color = "coral", size = 1) +
  labs(title = "TMRS Field Dendrogram (2006-2010)", 
       x = "", y = "Cos. Similarity Distance", caption = "Total 3.117 Abstracts") +
  theme_minimal() +
  theme(axis.text.x = element_blank(),
        axis.ticks.x = element_blank(),
        panel.grid.major = element_blank(),
        panel.grid.minor = element_blank())


plotden2 <- ggplot() +
  geom_segment(data = hc_data2$segments, 
               aes(x = x, y = pmax(y, 0), xend = xend, yend = pmax(yend, 0))) + 
  labs(title = "TMRS Field Dendrogram (2006-2010)", 
       x = "", y = "Cos. Similarity Distance", caption = "Total 1.801 Abstracts") +
  theme_minimal() +
  theme(axis.text.x = element_blank(),
        axis.ticks.x = element_blank(),
        panel.grid.major = element_blank(),
        panel.grid.minor = element_blank())

# Quinquenial 3

# Extract TMRS matrices
for (i in seq_along(tm3)) {
  assign(paste0("A_element_", i), tm3[[i]])
}

# Perform hierarchical clustering 
hc3 <- hclust(as.dist(A_element_3), method = "median")

# Plot

hc_data3 <- ggdendro::dendro_data(hc3)

plotden3 <- ggplot() +
  geom_segment(data = hc_data3$segments, aes(x = x, y = y, xend = xend, yend = yend)) +
  geom_label(data = sampled_labels, aes(x = x, y = y, label = label), 
             hjust = 1, vjust = 1, angle = 90, size = 3, fill = "cornflowerblue", label.size = 0) +
  # Add a dashed horizontal line for cluster 3
  geom_hline(yintercept = 0.06, linetype = "dashed", color = "coral", size = 1) +
  labs(title = "TMRS Field Dendrogram (2011-2015)", 
       x = "", y = "Cos. Similarity Distance") +
  theme_minimal() +
  theme(axis.text.x = element_blank(),
        axis.ticks.x = element_blank(),
        panel.grid.major = element_blank(),
        panel.grid.minor = element_blank())


plotden3 <- ggplot() +
  geom_segment(data = hc_data3$segments, 
               aes(x = x, y = pmax(y, 0), xend = xend, yend = pmax(yend, 0))) + 
  labs(title = "TMRS Field Dendrogram (2006-2010)", 
       x = "", y = "Cos. Similarity Distance", caption = "Total 1.801 Abstracts") +
  theme_minimal() +
  theme(axis.text.x = element_blank(),
        axis.ticks.x = element_blank(),
        panel.grid.major = element_blank(),
        panel.grid.minor = element_blank())

# Quinquenial 4

# Extract TMRS matrices
for (i in seq_along(tm4)) {
  assign(paste0("A_element_", i), tm4[[i]])
}

# Perform hierarchical clustering 
hc4 <- hclust(as.dist(A_element_4), method = "median")

# Plot

hc_data4 <- ggdendro::dendro_data(hc4)


plotden3 <- ggplot() +
  geom_segment(data = hc_data4$segments, aes(x = x, y = y, xend = xend, yend = yend)) +
  geom_label(data = sampled_labels, aes(x = x, y = y, label = label), 
             hjust = 1, vjust = 1, angle = 90, size = 3, fill = "cornflowerblue", label.size = 0) +
  # Add a dashed horizontal line for cluster 3
  geom_hline(yintercept = 0.06, linetype = "dashed", color = "coral", size = 1) +
  labs(title = "TMRS Field Dendrogram (2016-2021)", 
       x = "", y = "Cos. Similarity Distance") +
  theme_minimal() +
  theme(axis.text.x = element_blank(),
        axis.ticks.x = element_blank(),
        panel.grid.major = element_blank(),
        panel.grid.minor = element_blank())


plotden4 <- ggplot() +
  geom_segment(data = hc_data4$segments, 
               aes(x = x, y = pmax(y, 0), xend = xend, yend = pmax(yend, 0))) + 
  labs(title = "TMRS Field Dendrogram (2006-2010)", 
       x = "", y = "Cos. Similarity Distance", caption = "Total 1.801 Abstracts") +
  theme_minimal() +
  theme(axis.text.x = element_blank(),
        axis.ticks.x = element_blank(),
        panel.grid.major = element_blank(),
        panel.grid.minor = element_blank())






