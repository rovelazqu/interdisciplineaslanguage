# PAPER CODE – STM / Structural Topic Model
# Estimation followed the procedures described and presented by 
# Roberts ME, Stewart BM, Tingley D. stm: An R Package for Structural Topic
# Models. Journal of Statistical Software. 2019;91:1–40. doi:10.18637/jss.v091.i02.

# Data Availability:
# The following code reproduces the STM (Structural Topic Model) results.
# The dataset is publicly available on the GitHub repository of the paper and 
# consists of four tables, each representing the corpus for a specific period.


# Note: The data has been edited to ensure anonymity
# and to comply with the data use requirements of data providers (SciSciNet and OpenAlex).

#Libraries
library(stm)
library(hunspell)
library(dplyr)
library(ggplot2)
library(purrr)
library(readr)
library(stringr)
library(tidytext)
library(tidyverse)
library(tm)

# Goodness-of-Fit Procedures for Structural Topic Models #

# 1.- Data: 

lat_d1 <- read_csv("~/yourlocation/lat_d1.csv")
lat_d2 <- read_csv("~/yourlocation/lat_d2.csv")
lat_d3 <- read_csv("~/yourlocation/lat_d3.csv")
lat_d4 <- read_csv("~/yourlocation/lat_d4.csv")

# 2.- Functions: 

# a) Preprocess text and metadata for a given corpus
process_corpus <- function(df) {
  # Run STM's textProcessor with common cleaning settings
  tp <- textProcessor(
    df$ab, metadata = df,
    lowercase = TRUE, removestopwords = TRUE, removenumbers = TRUE,
    removepunctuation = TRUE, ucp = FALSE, stem = FALSE,
    wordLengths = c(3, Inf), sparselevel = 1, language = "en",
    verbose = TRUE, onlycharacter = FALSE, striphtml = FALSE,
    customstopwords = FALSE, custompunctuation = NULL, v1 = FALSE
  )
  
  # Prepare documents for STM
  out <- prepDocuments(tp$documents, tp$vocab, tp$meta)
  
  # Format metadata (convert numeric and factor variables)
  meta <- out$meta %>%
    mutate(
      across(c(year, references, citations), ~ as.numeric(.)),
      across(c(gen_prev, papsize, cluster), as.factor)
    )
  
  list(docs = out$documents, vocab = out$vocab, meta = meta)
}

# b) Run searchK for a given set of K values
run_searchK <- function(docs, vocab, meta, k_values) {
  set.seed(1234)  # reproducibility
  searchK(
    documents = docs, vocab = vocab, K = k_values, M = 10,
    prevalence = ~ year + references + citations + gen_prev + papsize + cluster,
    data = meta
  )
}

# c) Ensure numeric metrics are properly formatted
coerce_metrics <- function(df) {
  df %>% mutate(across(any_of(c("K","heldout","exclus","semcoh")),
                       ~ as.numeric(unlist(.))))
}

# d) Plot evaluation metrics (Held-out, Semantic Coherence, Exclusivity)
plot_metric <- function(df, metric, corpus_label) {
  ggplot(df, aes(x = K, y = .data[[metric]])) +
    geom_line(color = "black") +
    geom_point(color = "cornflowerblue", size = 3) +
    labs(
      caption = corpus_label,
      x = "K",
      y = c(heldout = "Held-out Likelihood",
            semcoh  = "Semantic Coherence",
            exclus  = "Exclusivity")[metric],
      title = paste(c(heldout = "Held-out Likelihood",
                      semcoh  = "Semantic Coherence",
                      exclus  = "Exclusivity")[metric],
                    corpus_label)
    ) +
    theme_minimal()
}

# 3.- Optimal K : 

# a) List of corpora to process (with descriptive labels)
corpora <- list(
  "Corpus I"   = lat_d1,
  "Corpus II"  = lat_d2,
  "Corpus III" = lat_d3,
  "Corpus IV"  = lat_d4
)

# b) Intervals of K to test (5, 5–10, 5–15, 5–20)
k_values_list <- list(5, 5:10, 5:15, 5:20)

# c) Run all corpora 

corpus_results <- imap(corpora, function(df, label) {
  # Step 1: Preprocess corpus
  pcs <- process_corpus(df)
  
  # Step 2: Run searchK for each K interval
  sr <- map(k_values_list, ~ run_searchK(pcs$docs, pcs$vocab, pcs$meta, .x))
  
  # Step 3: Extract results and coerce metrics to numeric
  results_list <- map(sr, "results") %>% map(coerce_metrics)
  
  # Step 4: Select results from widest K range (5–20) for plotting
  res_for_plot <- results_list[[4]]
  
  # Step 5: Generate evaluation plots for this corpus
  plots <- list(
    held   = plot_metric(res_for_plot, "heldout", label),
    semcoh = plot_metric(res_for_plot, "semcoh",  label),
    exclus = plot_metric(res_for_plot, "exclus",  label)
  )
  
  list(
    docs = pcs$docs,
    vocab = pcs$vocab,
    meta = pcs$meta,
    search_results = sr,
    results_list = results_list,
    plots = plots
  )
})


# d) Create separate named objects for each corpus’ results and plots

list2env(setNames(lapply(corpus_results, `[[`, "results_list"),
                  paste0("results_", gsub(" ", "_", tolower(names(corpus_results))))),
         envir = .GlobalEnv)

list2env(setNames(lapply(corpus_results, `[[`, "plots"),
                  paste0("plots_", gsub(" ", "_", tolower(names(corpus_results))))),
         envir = .GlobalEnv)


# Structural Topic Models #

# 1.- Parameters: 

K_TOPIC <- 13
SEED_FIT <- 831
EM_ITERS <- 1500

set.seed(SEED_FIT)

# 2.- Functions: 

# a) Coerce metadata columns if present (robust to missing vars)
coerce_meta_safely <- function(meta) {
  num_vars   <- c("year", "references", "citations", "papsize")
  factor_vars <- c("gen_prev", "cluster")
  
  # Numeric where available
  for (v in num_vars) {
    if (v %in% names(meta)) {
      meta[[v]] <- suppressWarnings(as.numeric(meta[[v]]))
    }
  }
  # Factors where available
  for (v in factor_vars) {
    if (v %in% names(meta)) {
      meta[[v]] <- as.factor(meta[[v]])
    }
  }
  meta
}

# b) Build prevalence function from variables 
build_prevalence_formula <- function(meta) {
  rhs_vars <- intersect(
    c("year", "references", "citations", "gen_prev", "papsize", "cluster"),
    names(meta)
  )
  if (length(rhs_vars) == 0) {
    # No covariates available — use intercept only
    as.formula("~ 1")
  } else {
    as.formula(paste("~", paste(rhs_vars, collapse = " + ")))
  }
}

# 3.- Fit STM for one corpus: preprocess → fit → effects → plots
fit_stm_corpus <- function(df, corpus_label, k = K_TOPIC, seed = 15, em_its = EM_ITERS) {
  
  # a) Pre-STM: clean rows with empty/NA abstracts (column 'ab')
  df <- df %>% filter(!is.na(ab) & trimws(ab) != "")
  
  # b) Text processing: tokenize, remove stops/numbers/punct., etc.
  processed <- textProcessor(
    documents = df$ab,
    metadata  = df,
    lowercase = TRUE,
    removestopwords = TRUE,
    removenumbers   = TRUE,
    removepunctuation = TRUE,
    ucp = FALSE,
    stem = FALSE,
    wordLengths = c(3, Inf),
    sparselevel = 1,
    language = "en",
    verbose = TRUE,
    onlycharacter = FALSE,
    striphtml = FALSE,
    customstopwords = FALSE,
    custompunctuation = NULL,
    v1 = FALSE
  )
  

  # Prepare documents for STM (drop rare terms/docs, align vocab)
  out   <- prepDocuments(processed$documents, processed$vocab, processed$meta)
  docs  <- out$documents
  vocab <- out$vocab
  meta  <- coerce_meta_safely(out$meta)
  
  # Prevalence formula based on *available* metadata columns
  prev_formula <- build_prevalence_formula(meta)
  

  # c) STM estimation (K topics) with covariates in prevalence
  message(sprintf("[STM] Fitting %s with K = %d", corpus_label, k))
  stm_fit <- stm(
    documents   = docs,
    vocab       = vocab,
    K           = k,
    prevalence  = prev_formula,
    data        = meta,
    seed        = seed,
    max.em.its  = em_its
  )
  

# 4.- Topic proportions (θ): summarize mean prevalence across docs
  
  k_fit <- stm_fit$settings$dim$K
  topic_means <- colMeans(as.data.frame(stm_fit$theta))
  
  plot_data <- data.frame(
    Topic      = factor(seq_len(k_fit), levels = seq_len(k_fit)),
    Proportion = topic_means
  )
  
  # a) Title and caption use label + realized n-docs after prep
  n_docs_out <- length(docs)
  prop_plot <- ggplot(plot_data, aes(x = Topic, y = Proportion, fill = Proportion)) +
    geom_bar(stat = "identity") +
    scale_fill_gradient(low = "#619CFF", high = "#F8766D") +
    theme_minimal() +
    labs(
      title   = sprintf("Topic Proportions — %s", corpus_label),
      x = "Topic", y = "Mean Proportion",
      caption = sprintf("n = %s abstracts", scales::comma(n_docs_out))
    ) +
    theme(axis.text.x = element_text(angle = 45, hjust = 1))
  

# 5.- Effects: estimate effect sizes for the same prevalence covariates

  # Build formula like: 1:K ~ year + references + ... using available vars
  rhs_vars <- all.vars(prev_formula)[-1]  # drop intercept
  eff_form <- if (length(rhs_vars) == 0) {
    as.formula(paste0("1:", k_fit, " ~ 1"))
  } else {
    as.formula(paste0("1:", k_fit, " ~ ", paste(rhs_vars, collapse = " + ")))
  }
  
  est_eff <- estimateEffect(
    formula = eff_form,
    stmobj  = stm_fit,
    metadata = meta,
    uncertainty = "Global"
  )
  
  # a) Plot cluster effect if 'cluster' is available
  cluster_plot <- NULL
  if ("cluster" %in% rhs_vars) {
    cluster_plot <- function() {
      plot(
        est_eff,
        covariate = "cluster",
        model = stm_fit,
        method = "pointestimate",
        main = sprintf("Effect of Interdisciplinarity (cluster) — %s", corpus_label)
      )
    }
  }
  
  list(
    model = stm_fit,
    effects = est_eff,
    topic_plot = prop_plot,
    cluster_plot = cluster_plot,
    n_docs = n_docs_out
  )
}

# save ggplot safely if provided
save_plot_if_any <- function(plot_obj, path, width = 12, height = 4, dpi = 300) {
  if (inherits(plot_obj, "ggplot")) {
    ggsave(path, plot = plot_obj, width = width, height = height, dpi = dpi)
  }
}


# 6.- Results:


# ---- Corpus 1: STM fitting (K=13) on 2000–2005 ----
c1 <- fit_stm_corpus(
  df = lat_d1,
  corpus_label = "2000–2005"
)
save_plot_if_any(c1$topic_plot, "topic_props_2000_2005.png")
if (!is.null(c1$cluster_plot)) c1$cluster_plot()

# ---- Corpus 2: STM fitting (K=13) on 2006–2010 ----
c2 <- fit_stm_corpus(
  df = lat_d2,
  corpus_label = "2006–2010"
)
save_plot_if_any(c2$topic_plot, "topic_props_2006_2010.png")
if (!is.null(c2$cluster_plot)) c2$cluster_plot()

# ---- Corpus 3: STM fitting (K=13) on 2011–2015 ----
c3 <- fit_stm_corpus(
  df = lat_d3,
  corpus_label = "2011–2015"
)
save_plot_if_any(c3$topic_plot, "topic_props_2011_2015.png")
if (!is.null(c3$cluster_plot)) c3$cluster_plot()

# ---- Corpus 4: STM fitting (K=13) on 2016–2021 ----
c4 <- fit_stm_corpus(
  df = lat_d4,
  corpus_label = "2016–2021"
)
save_plot_if_any(c4$topic_plot, "topic_props_2016_2021.png")
if (!is.null(c4$cluster_plot)) c4$cluster_plot()


